import { createApp } from 'vue'
import App from './App.vue'
import './registerServiceWorker'
import './assets/scss/index.scss'

createApp(App).mount('#app')
