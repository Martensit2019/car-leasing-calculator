<template>
  <CalculateForm />
</template>

<script>
import CalculateForm from "./components/CalculateForm.vue";

export default {
  name: "App",
  components: {
    CalculateForm,
  },
};
</script>